#include <iostream>
#include <cstdlib>
#include <locale>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    char nome[20];
    cout <<"Meu nome é" << endl;
    cin >> nome;
    cout << "Sou do curso de Sistema de Informação." << endl;
    cout << "Estou no Primeiro Ano." << endl;
    cout << "Gosto de programação!!!" << endl;
    return 0;
}

