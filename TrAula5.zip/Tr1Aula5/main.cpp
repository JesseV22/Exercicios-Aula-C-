
#include <iostream>
#include <cstdlib>
#include <iomanip>


using namespace std;

int main(int argc, char** argv) {
    
    cout << "Sou calouro de BSI!!!!”" << endl;
    
    return 0;
}

