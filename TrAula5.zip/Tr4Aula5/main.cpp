/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Jessé Vitorino
 *
 * Created on 2 de maio de 2022, 21:10
 */

#include <iostream>
#include <cstdlib>
#include <locale>
#include <cmath>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float perimetro,raio;
    
    cout << "Informe o valor do  raio do circulo :" ;
    cin >> raio;
    perimetro;
    cout << "O perimetro do circulo é : " << 2 * raio << endl;
    cout << "A área do Circulo é: "<< pow(raio,2) * M_PI << endl;
    
    return 0;
}

